-- server.lua

RegisterServerEvent('playerDied')
AddEventHandler('playerDied', function()
    TriggerClientEvent('playerDied', -1, source) -- Inform all clients that the player died
end)

RegisterCommand('startcopsrobbers', function(source, args, rawCommand)
    TriggerClientEvent('startCopsVsRobbers', -1) -- Start the Cops vs Robbers game mode for all clients
end, false)