-- __resource.lua

resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

client_script 'client.lua'
server_script 'server.lua'
shared_script 'config.lua'

-- Add any other necessary dependencies or resources here